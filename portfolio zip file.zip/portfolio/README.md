# MapRank — Professional GMB & Local SEO Agency Platform

A complete, modern, and fully responsive website and management system built for **MapRank**, a specialized digital marketing agency founded and owned by **Arsalan Abbas**.

Designed specifically for MapRank and its prospective clients, this platform establishes a credible, trustworthy, and modern agency presence while remaining completely honest about its newly established status.

---

## 🏢 Business Overview

- **Agency Name:** MapRank
- **Agency Type:** Google Business Profile (GMB) & Local SEO Agency
- **Founder & Owner:** Arsalan Abbas
- **Official Email:** [abbasarsalan462@gmail.com](mailto:abbasarsalan462@gmail.com)
- **Phone / WhatsApp:** [+92 311 8356461](https://wa.me/923118356461?text=Hello%20Arsalan%2C%20I%20would%20like%20to%20discuss%20GMB%20%26%20Local%20SEO%20services%20for%20my%20business.)
- **Location:** Remote / Online (Serving clients worldwide)
- **Instagram:** [@map_raink](https://instagram.com/map_raink)
- **Facebook:** [MapRaink](https://facebook.com/MapRaink)
- **Core Specialization:**
  1. Google Business Profile (GMB) Management & Optimization
  2. Local SEO & Local Search Visibility

---

## ✨ System Features

### 1. Modern Agency Frontend (`/frontend`)
- **Brand Identity:** High-contrast Navy & Slate dark palette (`#0B132B`, `#0F172A`), crisp typography (Plus Jakarta Sans & Inter), and vibrant Blue accents.
- **Hero Section:**
  - Clear agency heading & value proposition.
  - **"Get Started"** direct smooth-scroll button.
  - **"WhatsApp Us"** button opening WhatsApp directly with a pre-filled client message.
  - Local Presence framework visual mockup.
- **About MapRank:** Honest, confident narrative highlighting the agency's dedicated focus on local search without inflated or false claims.
- **Specialized Services:** Strictly focused on:
  - **Google Business Profile (GMB):** Profile setup, information structuring, categories/attributes mapping, services setup, media guidelines, Google updates/posts, and review response strategy.
  - **Local SEO:** Local presence auditing, NAP consistency, local citation building & cleanup, service area keyword mapping, and on-page local signal alignment.
  - Includes a transparent notice on search engine algorithms and white-hat practices.
- **About the Owner (Arsalan Abbas):**
  - Natural introduction highlighting diligence, punctuality, and client dedication.
  - **Transparent Education Status:** Intermediate 2nd Year (Ongoing) and Aptech 3-Year Diploma (Ongoing).
  - **Additional Skills Card:** Founder's technical background (HTML, CSS, JavaScript, Bootstrap, MySQL, Web Designing) clearly separated from core agency marketing services.
- **Why Choose MapRank:** 7 core working principles (Professional Communication, Punctual & Responsible Approach, Client-Focused Service, Clear Communication, Remote Service Worldwide, Attention to Business Requirements, Honest & Transparent Approach).
- **Responsive Navigation:**
  - Desktop: Logo on left, navigation links, direct WhatsApp button and Admin link.
  - Mobile: Smooth animated hamburger menu that auto-closes on link selection or outside tap.
- **Floating WhatsApp Widget:** Fixed bottom-right chat button with radar pulse animation and pre-filled message.

### 2. Client Inquiry System
- **Fields:** Full Name, Email, Phone/WhatsApp, Business Name, Business Website (optional), Service Interested In, Project Message, and Optional File/CV Upload.
- **Validation:** Double validation (frontend HTML5 & JavaScript checks + server-side validation).
- **File Upload:** Whitelist enforcement (PDF, DOC, DOCX, JPG, PNG, WEBP, TXT), 5MB size limit, malicious script rejection, and secure server disk storage with randomized filenames.
- **Success Feedback:** Displays: *"Thank you for contacting MapRank. Your inquiry has been received. We will get back to you soon."*

### 3. Automated Email Notifications
- Sends a structured HTML notification to **`abbasarsalan462@gmail.com`** whenever an inquiry is submitted.
- Includes client name, email, phone, business name, website, service, message, and attaches the uploaded file.
- Non-blocking async dispatch ensures immediate client response even while emails are transmitting.

### 4. Admin Portal (`/frontend/admin`)
- **Protected Access:** Requires authentication using bcrypt password verification and signed JWT tokens.
- **Dashboard Metrics:** Real-time counters for Total Inquiries, New Inquiries, In Progress, and Completed/Closed.
- **Live Search & Filter:** Search by client name, email, business name, or service; filter by status (*New*, *Contacted*, *In Progress*, *Completed*, *Closed*).
- **Inquiry Detail Modal:** Comprehensive view of the inquiry, full message, website link, and direct WhatsApp click-to-chat button with client.
- **Status Updates:** Instant one-click status transitions.
- **File Management:** Download client-attached documents with their original filenames.
- **Inquiry Deletion:** Delete inquiries and auto-purge associated files from disk with confirmation dialog.

### 5. Production MySQL Database Integration
- Full MySQL support via `mysql2/promise` with auto-migration of `inquiries` and `admins` tables.
- Built-in zero-config local store fallback for instant development testing without requiring an active MySQL daemon.

---

## 🗂️ Project Directory Structure

```text
portfolio/
├── frontend/                     # Static Agency Website & Admin Portal (Ready for Netlify)
│   ├── index.html                # Main MapRank Agency Website
│   ├── _redirects                # Netlify Clean URL & API Proxy Rules
│   ├── netlify.toml              # Netlify Build & Security Headers
│   ├── admin/
│   │   └── index.html            # Secure Admin Dashboard & Login Portal
│   ├── assets/
│   │   ├── favicon.svg           # High-resolution MapRank Vector Favicon
│   │   └── logo.svg              # Official Vector Brand Logo
│   ├── css/
│   │   ├── style.css             # Main Website Stylesheet & Responsive Breakpoints
│   │   └── admin.css             # Admin Dashboard Stylesheet
│   └── js/
│       ├── config.js             # API Configuration & Endpoints
│       ├── main.js               # Frontend Logic, Validation & Navigation
│       └── admin.js              # Admin Dashboard Logic & API Communication
│
├── backend/                      # Node.js & Express REST API Server
│   ├── .env                      # Active Environment Variables
│   ├── .env.example              # Environment Variables Template
│   ├── package.json              # Server Dependencies & Scripts
│   ├── uploads/                  # Secure Directory for Client Uploads
│   ├── database/
│   │   ├── schema.sql            # Production MySQL Table Definitions & Seed
│   │   └── seed.js               # Admin Account Seeder Script
│   └── src/
│       ├── server.js             # Express Server Initialization & Static Serving
│       ├── config/
│       │   └── db.js             # MySQL Pool, Migrations & Datastore Adapter
│       ├── controllers/
│       │   ├── authController.js    # Admin Login & JWT Issuance
│       │   └── inquiryController.js # Inquiries CRUD, Uploads & Statuses
│       ├── middleware/
│       │   ├── auth.js           # JWT Verification Middleware
│       │   └── upload.js         # Multer Whitelist & File Size Validation
│       ├── routes/
│       │   └── api.js            # API Endpoints
│       └── utils/
│           └── email.js          # Nodemailer Notification Service
│
├── README.md                     # Project Documentation
└── DEPLOYMENT.md                 # Netlify + Render + MySQL Deployment Guide
```

---

## 🚀 Running Locally

### Prerequisites
- Node.js (v18 or higher) and npm installed.

### 1. Start the Backend Server
```powershell
cd "c:\Users\fattani computers\Desktop\portfolio\backend"
npm start
```
The server will start on port `5000`:
- **Main Website:** [http://localhost:5000](http://localhost:5000)
- **Admin Portal:** [http://localhost:5000/admin](http://localhost:5000/admin)
- **API Health Check:** [http://localhost:5000/api/health](http://localhost:5000/api/health)

### 2. Admin Credentials
- **Username:** `arsalan`
- **Password:** `MapRank2026!`

*(You can change the credentials in `backend/.env` or run `npm run seed`).*

---

## 🌐 Deployment Architecture

As specified, the system is architected for clean, decoupled production hosting:
- **Frontend** → Hosted on **Netlify** (Free, instant global CDN).
- **Backend API** → Hosted on **Render**, **Railway**, or **Koyeb** (Free/low-cost Node.js hosting).
- **Database** → Hosted on **TiDB Serverless** or **Railway MySQL** (Free MySQL cloud instances).

For step-by-step instructions with screenshots and environment variable setup, refer to [DEPLOYMENT.md](file:///c:/Users/fattani%20computers/Desktop/portfolio/DEPLOYMENT.md).
